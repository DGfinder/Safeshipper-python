# dangerous_goods/forms.py
from django import forms
# from .models import DangerousGood # Example

# class DangerousGoodForm(forms.ModelForm):
#     class Meta:
#         model = DangerousGood
#         fields = '__all__' 
